// v6.1.59: opens straight to the account. If the popup showed the account last
// time, the sign-in card and the startup loader stay invisible for the moment
// it takes to paint the saved account, so the popup never flashes them.
(() => {
  try { if (localStorage.getItem('popupLastScreen') === 'app') document.documentElement.classList.add('boot-app'); } catch {}
  // Safety net: never keep a screen hidden for long.
  setTimeout(() => document.documentElement.classList.remove('boot-app'), 1500);
})();

// v6.1.62: the popup never sits scrolled sideways. If Chrome gives the popup a
// few pixels less than it asked for (Windows display scaling), a focus or
// scroll-into-view could shift the page left and leave a gap beside the header.
(() => {
  const snap = () => { if (window.scrollX) window.scrollTo(0, window.scrollY); };
  window.addEventListener('scroll', snap, { passive: true });
  window.addEventListener('resize', snap);
})();
