// v6.1.53 — brand theme (LogIn / TrucksMate) for this one extension.
// The Main Admin tags a Manager with a theme on the dashboard; every Shared
// Profile under that Manager, and their clients, receive it inside calls the
// extension already makes (get_client_state / get_extension_policy).
// The chosen theme is cached in chrome.storage.local (survives sign-out and
// restarts) and mirrored to this extension's localStorage so every page paints
// the right brand on its very first frame. The TrucksMate logo ships inside
// the extension (assets/trucksmate-logo.png): nothing is ever downloaded.
globalThis.CS = globalThis.CS || {};
CS.Theme = (() => {
  const KEY = 'brandTheme';
  const THEMES = Object.freeze({
    login: Object.freeze({ id: 'login', name: 'LogIn' }),
    trucksmate: Object.freeze({
      id: 'trucksmate', name: 'TrucksMate', logo: 'assets/trucksmate-logo.png',
      phone: '03200485873', phoneLabel: '032 00485873'
    })
  });
  const norm = t => (t === 'trucksmate' ? 'trucksmate' : 'login');
  const hasDoc = typeof document !== 'undefined';

  const CSS = `
html:not([data-brand="trucksmate"]) .trucksmate-top-banner{display:none!important}
html[data-brand="trucksmate"]{--accent:#2f5bff;--accent-hover:#2451f5;--accent-press:#1d45e0;--accent-soft:rgba(47,91,255,.16);--info:#1d45e0;--info-line:rgba(47,91,255,.18);--primary:#2f5bff;--primary-2:#2f5bff}
html[data-brand="trucksmate"] .trucksmate-top-banner{box-sizing:border-box;width:100%;height:56px;margin:0;padding:10px 20px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.92);-webkit-backdrop-filter:saturate(180%) blur(16px);backdrop-filter:saturate(180%) blur(16px);border-bottom:1px solid rgba(0,0,0,.06);flex:0 0 56px;position:sticky;top:0;z-index:40}
html[data-brand="trucksmate"] .trucksmate-top-banner img{display:block;width:auto;height:30px;max-width:230px;object-fit:contain}
html[data-brand="trucksmate"] .topbar .header-app-logo{display:none!important}
html[data-brand="trucksmate"] .logo-wrap{width:auto;height:auto;min-height:48px}
html[data-brand="trucksmate"] .logo-wrap img{width:auto;height:44px;max-width:240px;filter:none}
html[data-brand="trucksmate"]:not([data-brand-ready]) .logo-wrap img{visibility:hidden}`;

  function readMirror() { try { return norm(localStorage.getItem(KEY)); } catch { return 'login'; } }
  function writeMirror(t) { try { localStorage.setItem(KEY, t); } catch {} }

  // Status pages: swap the logo; the Suspended page gets the brand's phone.
  function decorate(t) {
    const th = THEMES[t];
    document.querySelectorAll('.logo-wrap img').forEach(img => {
      if (!img.dataset.loginSrc) img.dataset.loginSrc = img.getAttribute('src') || 'logo-login-app.png';
      const src = t === 'trucksmate' ? th.logo : img.dataset.loginSrc;
      if (img.getAttribute('src') !== src) img.setAttribute('src', src);
      img.alt = t === 'trucksmate' ? 'TrucksMate' : 'LogIn logo';
    });
    document.querySelectorAll('[data-theme-contact]').forEach(box => {
      let node;
      if (th.phone) {
        node = document.createElement('a');
        node.className = 'btn btn-phone'; node.href = `tel:${th.phone}`; node.textContent = `Contact ${th.phoneLabel}`;
      } else {
        node = document.createElement('button');
        node.className = 'btn btn-contact'; node.type = 'button'; node.disabled = true; node.textContent = 'Contact Administrator';
      }
      box.replaceChildren(node);
    });
    document.documentElement.dataset.brandReady = '1';
  }

  function apply(theme) {
    if (!hasDoc) return;
    const t = norm(theme);
    document.documentElement.dataset.brand = t;
    writeMirror(t);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => decorate(norm(document.documentElement.dataset.brand)), { once: true });
    else decorate(t);
  }

  async function get() {
    try { const r = await chrome.storage.local.get(KEY); return norm(r[KEY]); } catch { return hasDoc ? readMirror() : 'login'; }
  }

  // Called with the theme the server sent. Anything that is not a string
  // (an older database without themes, a failed call) changes nothing.
  async function save(theme) {
    if (typeof theme !== 'string') return;
    const t = norm(theme);
    try {
      const cur = await chrome.storage.local.get(KEY);
      if (cur[KEY] !== t) await chrome.storage.local.set({ [KEY]: t });
    } catch {}
    apply(t);
  }

  if (hasDoc) {
    const style = document.createElement('style');
    style.id = 'cs-theme'; style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);
    apply(readMirror());
    get().then(apply).catch(() => {});
    try { chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch[KEY]) apply(ch[KEY].newValue); }); } catch {}
  }

  return Object.freeze({ KEY, THEMES, save, get, current: () => (hasDoc ? norm(document.documentElement.dataset.brand) : 'login') });
})();
