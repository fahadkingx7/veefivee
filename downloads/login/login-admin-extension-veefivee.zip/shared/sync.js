globalThis.CS = globalThis.CS || {};
CS.Sync = (() => {
  // force=true always reads the server copy. Use it when the cached key fails
  // to decrypt a snapshot, or before an Admin publishes a new snapshot.
  async function getGroupKey(subadminUid, token, {force=false}={}){
    const uid=String(subadminUid||'').trim();
    if(!uid)return '';
    const cacheKey=`syncGroupKey:${uid}`;
    if(!force){
      const local=await CS.Store.get(cacheKey).catch(()=>({}));
      if(local[cacheKey])return String(local[cacheKey]);
    }

    const r=await CS.Firebase.getDoc(['users',uid,'syncKey','config'],token);
    const key=r.exists?String(r.data.key||''):'';
    if(key)await CS.Store.set({[cacheKey]:key}).catch(()=>{});
    else await CS.Store.remove(cacheKey).catch(()=>{});
    return key;
  }
  async function ensureGroupKey(subadminUid, token){
    const uid=String(subadminUid||'').trim();
    // Always confirm against the server so a second Admin browser never keeps
    // encrypting with a key that lost the creation race.
    const current=await getGroupKey(uid,token,{force:true});
    if(current)return current;
    const key=await CS.Crypto.newKeyBase64();
    // Insert-only: if another browser created the key first, keep theirs.
    await CS.Firebase.createSyncKeyIfMissing(uid,{key,createdAt:CS.Util.now(),version:1},token);
    const winner=await getGroupKey(uid,token,{force:true});
    if(!winner)throw new Error('Synchronization key could not be created.');
    return winner;
  }
  return {getGroupKey,ensureGroupKey};
})();
