// v6.1.48: show which version is required.
(async()=>{try{const r=await chrome.storage.local.get('adminUpdateRequired');const u=r&&r.adminUpdateRequired;if(u&&u.minVersion){const el=document.getElementById('detail');if(el)el.textContent=`Version ${u.minVersion} or newer is required; this is version ${u.version}. Install the latest extension, then sign in again.`;}}catch{}})();
