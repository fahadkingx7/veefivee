const $=id=>document.getElementById(id);
let sites=[],site=null,proxy=null,blocked=[],proxyDirty=false,to=null;
function send(type,payload={},timeout=18000){return new Promise(resolve=>{let done=false;const t=setTimeout(()=>{if(done)return;done=true;resolve({ok:false,error:'Background service did not respond. Try again.'})},timeout);try{chrome.runtime.sendMessage({type,...payload},r=>{if(done)return;done=true;clearTimeout(t);resolve(r||{ok:false,error:chrome.runtime.lastError?.message||'No response'})})}catch(e){clearTimeout(t);done=true;resolve({ok:false,error:e.message||String(e)})}})}
function busy(b,on,label){if(!b)return;if(on){b.disabled=true;b.dataset.old=b.textContent;b.innerHTML=`<span class="spinner"></span>${label}`}else{b.disabled=false;b.textContent=b.dataset.old||label}}
function toast(m,isError=false){
  const e=$('statusBanner');
  e.className='alert '+(isError?'bad':'good');
  e.textContent=m;
  e.classList.remove('hidden');
  clearTimeout(to);
  to=setTimeout(()=>e.classList.add('hidden'),3200);
}
chrome.runtime.onMessage.addListener(msg=>{
  if(msg?.type!=='cookie-change-synced')return;
  const e=msg.event||{};
  const cookies=Number(e.cookies||0);
  toast(`Login updated • ${cookies} cookies synced`);
});
function show(id){['startup','connectivity','login','app','suspended','locked'].forEach(x=>$(x).classList.toggle('hidden',x!==id));document.documentElement?.classList?.remove('boot-app');try{localStorage.setItem('popupLastScreen',id)}catch{}}
function isConnectivityError(message){
  const m=String(message||'').toLowerCase();
  return navigator.onLine===false || m.includes('could not reach supabase') || m.includes('supabase request timed out') || m.includes('network error') || m.includes('failed to fetch') || m.includes('check your internet connection') || m.includes('internet connection') || m.includes('proxy health request') || m.includes('proxy connection') || m.includes('proxy could not be restored') || m.includes('proxy is not working') || m.includes('could not connect');
}
function showConnectivity(){
  const e=$('connectivityText');
  if(e)e.textContent='Internet or proxy may not be working. Please check your connection or proxy and try again.';
  show('connectivity');
}

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function setAdminFooterName(profile){const e=$('adminNameValue');const em=$('adminEmailValue');const name=String(profile?.displayName||profile?.name||'').trim();const email=String(profile?.email||'').trim();if(e)e.textContent=name||'—';if(em)em.textContent=email||'—';}
/* v6.1.61: shared websites as a simple list. Each row has a delete icon; the
   row asks "Remove …?" with Cancel / Remove before anything is removed. */
const TRASH_ICON='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>';
function siteHost(x){return String(x?.hostname||x?.name||'').replace(/^\.+/,'')||'Website';}
function renderSiteChips(){
  const box=$('siteChips'); if(!box) return;
  if(!sites.length){ box.innerHTML='<div class="site-rows-empty">No website shared yet. Open a website and click Share Login.</div>'; return; }
  box.innerHTML=sites.map(x=>{const h=esc(siteHost(x)), id=esc(x.id);
    return `<div class="site-row" data-site-id="${id}">
      <span class="site-tile" aria-hidden="true">${esc(siteHost(x)[0].toUpperCase())}</span>
      <span class="site-host" title="${h}">${h}</span>
      <button type="button" class="site-del" data-act="ask" aria-label="Remove ${h}" title="Remove">${TRASH_ICON}</button>
      <span class="site-confirm"><span class="site-confirm-q">Remove?</span><button type="button" class="site-cancel" data-act="cancel">Cancel</button><button type="button" class="site-remove" data-act="remove">Remove</button></span>
    </div>`;}).join('');
}
function renderSites(){renderSitesSelect();renderSiteChips();renderLastShared();}
/* v6.1.61: Last Shared = the newest Share Login on any of this Admin's websites. */
function formatShared(t){
  if(!Number.isFinite(t)||t<=0)return 'not yet';
  const d=new Date(t);
  return `${d.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}\n${d.toLocaleDateString('en-GB', {day:'numeric',month:'short',year:'numeric'})}`;
}
function renderLastShared(extra){
  let saved=0; try{ saved=Number(localStorage.getItem('adminLastSharedAt')||0); }catch{}
  const t=Math.max(saved, Date.parse(extra||'')||0, ...(Array.isArray(sites)?sites:[]).map(x=>Date.parse(x?.lastSyncAt||'')||0));
  if(t>saved){ try{ localStorage.setItem('adminLastSharedAt',String(t)); }catch{} }
  const el=$('adminLastShared'); if(el) el.textContent=formatShared(t);
}
async function onSiteRowClick(e){
  const btn=e?.target?.closest?.('button[data-act]'); if(!btn) return;
  const row=btn.closest('.site-row'); if(!row || row.classList.contains('removing')) return;
  const act=btn.dataset.act;
  if(act==='ask'){ $('siteChips').querySelectorAll('.site-row.confirming').forEach(r=>r.classList.remove('confirming')); row.classList.add('confirming'); row.querySelector('.site-cancel')?.focus?.(); return; }
  if(act==='cancel'){ row.classList.remove('confirming'); return; }
  if(act==='remove'){
    row.classList.add('removing'); btn.disabled=true; btn.textContent='Removing…';
    const r=await send('remove-site',{siteId:row.dataset.siteId});
    if(!r?.ok){ row.classList.remove('removing','confirming'); return toast(r?.error||'Could not remove the website.'); }
    sites=r.sites||[]; site=r.site||null; renderSites(); renderSite(); toast('Website removed');
  }
}
function renderSitesSelect(){const s=$('siteSelect');s.innerHTML='';if(!sites.length){s.innerHTML='<option value="">No managed websites</option>';site=null;$('siteCount').textContent='0';$('removeSite').disabled=true;return}sites.forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent=x.name||x.hostname;s.appendChild(o)});if(site)s.value=site.id;$('siteCount').textContent=String(sites.length);$('removeSite').disabled=!site}
function renderSite(){if(!site){$('currentSite').textContent='No website selected';$('currentSiteMeta').textContent='Open a website and choose Add Current.';$('siteBadge').className='badge info';$('siteBadge').innerHTML='<span class="dot"></span>No site';blocked=[];renderUrls();return}$('currentSite').textContent=site.name||site.hostname;$('currentSiteMeta').textContent=site.origin||site.hostname;$('siteBadge').className='badge good';$('siteBadge').innerHTML='<span class="dot"></span>Sharing';blocked=[...(site.blockedPatterns||[])];renderUrls()}
let proxyLoading=false;   // v6.1.57: true between a fast sign-in and the first refresh
function renderProxy(){
  if(proxyDirty)return;
  if(!proxy && proxyLoading){
    const badge=$('proxyBadge'),info=$('proxyInfo');
    badge.className='badge warn';badge.innerHTML='<span class="dot"></span>Checking';
    info.className='alert info';info.textContent='Loading saved proxy…';
    return;
  }
  const p=proxy||{};
  $('proxyHost').value=p.host||'';
  $('proxyPort').value=p.port||'';
  $('proxyScheme').value=p.scheme||'http';
  $('proxyUser').value=p.username||'';
  $('proxyPass').value=p.password||'';
  $('expectedIp').value=p.expectedIp||'';

  const configured=p.mode==='fixed_servers' && p.host && Number(p.port)>0;
  const hasExplicitError=!!String(p.lastError||'').trim();
  const checkedFailure=(p.lastCheckedAt && p.healthy===false);
  const hasConfirmedError=hasExplicitError || checkedFailure;

  // Keep the saved endpoint visible during startup, transient network errors,
  // and confirmed proxy failures. Never replace it with a scary"Not configured"
  // state when the proxy is actually configured.
  $('proxyAddress').textContent=configured ? String(p.host) : '—';
  $('proxyIp').textContent=configured ? String(p.port) : '—';
  $('proxyPortWrap').hidden=!configured;

  const working=!!configured && p.healthy===true && !hasConfirmedError;
  const checking=!!configured && !hasConfirmedError && p.healthy!==true;
  const badge=$('proxyBadge'),info=$('proxyInfo');
  if(working){
    badge.className='badge good';
    badge.innerHTML='<span class="dot"></span>Connected';
    info.className='alert good';
    info.textContent='Browser is using the saved proxy.';
  }else if(checking){
    badge.className='badge warn';
    badge.innerHTML='<span class="dot"></span>Checking';
    info.className='alert info';
    info.textContent='Proxy verification is pending.';
  }else{
    badge.className='badge bad';
    badge.innerHTML='<span class="dot"></span>Not Working';
    info.className='alert bad';
    info.textContent=p.lastError||'Proxy is not configured. Enter a working proxy.';
  }
}

function renderUrls(){
  const list=$('urlList');list.innerHTML='';
  blocked.forEach((url,index)=>{
    const row=document.createElement('div');row.className='url';
    const code=document.createElement('code');code.textContent=url;
    const button=document.createElement('button');button.className='x';button.type='button';
    button.textContent='×';button.setAttribute('aria-label','Remove blocked URL');
    button.addEventListener('click',()=>{blocked.splice(index,1);renderUrls();});
    row.appendChild(code);row.appendChild(button);list.appendChild(row);
  });
}
function isInternetError(message){const m=String(message||'').toLowerCase();return navigator.onLine===false || m.includes('network error') || m.includes('failed to fetch') || m.includes('check your internet connection') || m.includes('internet connection');}
function showConnectivityFailure(message){
  const existing=proxy||{};
  const text=navigator.onLine===false || /supabase|internet|network|timed out|failed to fetch/i.test(String(message||''))
    ? "Can't connect to the internet."
    : (String(message||'Proxy connection failed.'));
  proxy={...existing,mode:existing.mode||'fixed_servers',healthy:false,lastError:text,lastCheckedAt:new Date().toISOString()};
  renderProxy();
}
// v6.1.57: a refresh started before a sign-out (or another sign-in) is ignored
// when it returns, so the popup can never jump back to a signed-out account.
let uiEpoch=0;
async function refresh(){const mine=uiEpoch;const r=await send('refresh',{},45000);if(mine!==uiEpoch)return;if(r.signedOut)return show('login');if(!r.ok){if(isConnectivityError(r.error)){showConnectivity();return}return toast(r.error||'Refresh failed.');}setAdminFooterName(r.profile);sites=r.sites||[];site=r.site||null;proxy=r.proxy||proxy||null;renderSites();renderSite();renderProxy();show('app')}
$('loginBtn').onclick=async()=>{const b=$('loginBtn');const e=$('loginEmail').value.trim(),p=$('loginPassword').value;if(!e||!p){$('loginError').textContent='Enter email and password.';$('loginError').classList.remove('hidden');return}busy(b,true,'Signing in…');uiEpoch++;try{const r=await send('login',{email:e,password:p},30000);if(r.suspended)return show('suspended');if(!r.ok){if(isConnectivityError(r.error))return showConnectivity();$('loginError').textContent=r.error||'Sign in failed.';$('loginError').classList.remove('hidden');return}setAdminFooterName(r.profile);sites=r.sites||[];site=r.site||null;proxy=r.proxy||null;proxyLoading=!!r.pending;renderSites();renderSite();renderProxy();show('app');if(r.pending)refresh().catch(()=>{}).finally(()=>{proxyLoading=false;renderProxy()})}finally{busy(b,false,'Sign in')}};
$('logout').onclick=async()=>{const b=$('logout');uiEpoch++;try{localStorage.removeItem('adminLastSharedAt')}catch{}busy(b,true,'Signing out…');try{await send('logout')}finally{busy(b,false,'Sign out');show('login')}};
$('retrySuspended').onclick=refresh;
$('retryLocked').onclick=()=>send('warning-check').then(r=>r.ok?refresh():show('locked'));
$('siteSelect').onchange=async()=>{const id=$('siteSelect').value;if(!id)return;const r=await send('select-site',{siteId:id});if(!r.ok)return toast(r.error);site=r.site;renderSite()};
async function currentTab(){const t=await chrome.tabs.query({active:true,currentWindow:true});return t[0]?.url||''}
async function permissionFor(url){const u=new URL(url);if(!['http:','https:'].includes(u.protocol))throw new Error('Open a normal website first.');const ok=await chrome.permissions.contains({origins:[`${u.origin}/*`]});if(!ok){const granted=await chrome.permissions.request({origins:[`${u.origin}/*`]});if(!granted)throw new Error('Website permission was not granted.');}}
$('addCurrent').onclick=async()=>{const b=$('addCurrent');busy(b,true,'Adding…');try{const url=await currentTab();await permissionFor(url);const r=await send('add-current-site',{url},20000);if(!r.ok)throw new Error(r.error);sites=r.sites||sites;site=r.site||site;renderSites();renderSite();toast(r.created?'Website added.':'Website selected.')}catch(e){toast(e.message)}finally{busy(b,false,'＋ Add Current Website')}};
$('pushCurrent').onclick=async()=>{const b=$('pushCurrent');busy(b,true,'Pushing…');try{const url=await currentTab();await permissionFor(url);const r=await send('push-current',{},60000);if(!r.ok)throw new Error(r.error);site=r.site||site;sites=r.sites||sites;renderSites();renderLastShared(r.result?.lastSyncAt);renderSite();toast(`Login shared • ${r.result?.cookies??0} cookies`)}catch(e){toast(e.message)}finally{busy(b,false,'↗ Share Login')}};
const refreshUsersModal=$('refreshUsersModal');
function closeRefreshUsersModal(){refreshUsersModal?.classList.add('hidden');}
$('refreshUsers').onclick=()=>{refreshUsersModal?.classList.remove('hidden');};
$('cancelRefreshUsers').onclick=closeRefreshUsersModal;
$('cancelRefreshUsersX').onclick=closeRefreshUsersModal;
refreshUsersModal?.addEventListener('click',e=>{if(e.target===refreshUsersModal)closeRefreshUsersModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeRefreshUsersModal()});
$('confirmRefreshUsers').onclick=async()=>{
  const trigger=$('refreshUsers'), confirm=$('confirmRefreshUsers');
  closeRefreshUsersModal();
  busy(trigger,true,'Refreshing…');
  try{
    const r=await send('refresh-users',{},30000);
    if(!r.ok)throw new Error(r.error||'Could not refresh users.');
    toast('Refresh command sent to all Client devices.');
  }catch(e){toast(e.message||String(e))}
  finally{busy(trigger,false,'Refresh Users')}
};
if($('siteChips'))$('siteChips').onclick=onSiteRowClick;
$('removeSite').onclick=async()=>{if(!site)return;const r=await send('remove-site',{siteId:site.id});if(!r.ok)return toast(r.error);sites=r.sites||[];site=r.site||null;renderSites();renderSite();toast('Managed website removed')};
$('openProxy').onclick=()=>{$('proxyError').classList.add('hidden');proxyDirty=false;renderProxy();$('proxyModal').classList.remove('hidden')};
$('cancelProxy').onclick=()=>$('proxyModal').classList.add('hidden');
['proxyHost','proxyPort','proxyScheme','proxyUser','proxyPass','expectedIp'].forEach(id=>$(id).addEventListener('input',()=>proxyDirty=true));
$('saveProxy').onclick=async()=>{const b=$('saveProxy');$('proxyError').classList.add('hidden');busy(b,true,'Applying…');const raw={mode:'fixed_servers',scheme:$('proxyScheme').value,host:$('proxyHost').value.trim(),port:Number($('proxyPort').value),username:$('proxyUser').value,password:$('proxyPass').value,expectedIp:$('expectedIp').value.trim()};const r=await send('save-proxy',{proxy:raw},25000);busy(b,false,'Save & Apply Proxy');if(!r.ok){$('proxyError').textContent=r.error||'Proxy failed.';$('proxyError').classList.remove('hidden');return}proxy=r.proxy||proxy;proxyDirty=false;$('proxyModal').classList.add('hidden');renderProxy();toast(r.health?.ok?'Proxy connected.':'Proxy saved but is not working.')};
// v6.1.64: Check My IP opens veefivee's IP checker in a new tab.
const CHECK_MY_IP_URL='https://veefivee.com/tools/check-my-ip.html';
if($('checkMyIp')) $('checkMyIp').onclick=()=>{ chrome.tabs.create({url:CHECK_MY_IP_URL,active:true}).catch(()=>{}); try{window.close();}catch{} };
$('reconnectProxy').onclick=async()=>{const b=$('reconnectProxy');busy(b,true,'Checking…');const r=await send('reconnect-proxy',{},25000);busy(b,false,'Reconnect');if(!r.ok&&r.proxy===undefined&&isConnectivityError(r.error))return showConnectivity();if(!r.ok&&r.proxy===undefined)return toast(r.error||'Proxy check failed.');proxy=r.proxy||proxy;renderProxy();toast(r.health?.ok?'Proxy connected.':'Proxy is not working.')};
$('addUrl').onclick=()=>{const v=$('urlInput').value.trim();if(!v)return;if(!/^https?:\/\//i.test(v))return toast('Use an http:// or https:// URL pattern.');blocked.push(v);$('urlInput').value='';renderUrls()};window.removeUrl=i=>{blocked.splice(i,1);renderUrls()};$('saveUrls').onclick=async()=>{if(!site)return toast('Select a managed website first.',true);const r=await send('save-blocked',{patterns:blocked});if(!r.ok||!r.site)return toast(r.error||'Could not save blocked URLs.',true);site=r.site;sites=sites.map(s=>s.id===site.id?site:s);renderSite();toast('Blocked URL rules saved')};

$('checkAgainConnectivity')?.addEventListener('click',async()=>{
  const b=$('checkAgainConnectivity');
  if(!b || b.disabled)return;
  const started=performance.now();
  b.classList.add('connectivity-checking');
  b.setAttribute('aria-busy','true');
  busy(b,true,'Checking…');
  try{if(typeof startup==='function')await startup();else window.location.reload();}catch(e){showConnectivity();}
  finally{
    const wait=Math.max(0,450-(performance.now()-started));
    if(wait)await new Promise(r=>setTimeout(r,wait));
    if(b){
      busy(b,false,'Check again');
      b.classList.remove('connectivity-checking');
      b.removeAttribute('aria-busy');
    }
  }
});
window.addEventListener('offline',()=>showConnectivity());
// v6.1.64: open instantly from the data saved last time, then run the server
// checks (sign-in refresh, suspension, minimum version) in the background. The
// checks only change the screen when something is wrong; actions always go
// through the server, which refuses suspended accounts anyway.
let cookieToastShown=false;
function showAccount(r){
  setAdminFooterName(r.profile);
  sites=r.sites||[];site=r.site||null;proxy=r.proxy||proxy||null;
  renderSites();renderSite();renderProxy();show('app');
  const ev=r.cookieChangeEvent;
  if(!cookieToastShown && ev?.at && Date.now()-Date.parse(ev.at)<30000){
    cookieToastShown=true;
    const cookies=Number(ev.cookies||0);
    toast(`Cookie change detected • ${cookies} cookies synced`);
  }
}
(async()=>{
  // v6.1.59: when the account was showing last time, skip the loader and open
  // straight to it (ui-boot.js reveals the loader after 1.5 s if still waiting).
  if(!document.documentElement?.classList?.contains('boot-app'))show('startup');
  if(navigator.onLine===false)return showConnectivity();
  // 1) Instant: saved data only, no network.
  const fast=await send('bootstrap-fast',{},3000).catch(()=>null);
  let shownFromSaved=false;
  if(fast?.ok){
    if(fast.suspended){ show('suspended'); shownFromSaved=true; }
    else if(fast.lockReason){ $('lockedText').textContent=fast.lockReason; show('locked'); shownFromSaved=true; }
    else if(fast.session&&fast.profile?.role==='subadmin'){ showAccount(fast); shownFromSaved=true; }
  }
  // 2) Background: the full checks, exactly as before.
  const r=await send('bootstrap',{},10000);
  if(!r.ok&&isConnectivityError(r.error))return showConnectivity();
  if(r.suspended || r.suspendedReason)return show('suspended');
  if(r.updateRequired){show('login');$('loginError').textContent=r.error||'Please update extension to continue.';$('loginError').classList.remove('hidden');return}
  if(r.lockReason){$('lockedText').textContent=r.lockReason;return show('locked')}
  if(r.session&&r.profile?.role==='subadmin'){
    showAccount(r);
    refresh().catch(()=>{});
  }else{
    show('login');
    // v6.1.48: explain why an outdated extension was signed out.
    try{const u=(await chrome.storage.local.get('adminUpdateRequired'))?.adminUpdateRequired;if(u&&String(u.version||'')===String(chrome.runtime.getManifest().version||'')){$('loginError').textContent='Please update extension to continue.';$('loginError').classList.remove('hidden')}}catch{}
  }
  void shownFromSaved;
})();
