// LogIn popup design helpers (v6.1.55). Visual only: adds an initials avatar
// next to the account name and a letter tile to each website row. It watches
// the elements popup.js already fills, so no popup logic changes.
(() => {
  const HUES = [214, 258, 330, 168, 24, 194, 284, 142, 8, 232];
  const hueFor = s => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return HUES[h % HUES.length]; };
  const initials = s => {
    const words = String(s || '').replace(/@.*/, '').split(/[\s._-]+/).filter(Boolean);
    return ((words[0]?.[0] || '') + (words[1]?.[0] || words[0]?.[1] || '')).toUpperCase() || '·';
  };
  function avatar(host, nameEl) {
    if (!host || !nameEl) return;
    let a = host.querySelector(':scope > .ui-avatar');
    if (!a) { a = document.createElement('span'); a.className = 'ui-avatar'; a.setAttribute('aria-hidden', 'true'); host.prepend(a); }
    const name = (nameEl.textContent || '').trim();
    const t = name && name !== '—' ? initials(name) : '';
    if (a.textContent !== t) a.textContent = t;
    a.style.setProperty('--h', String(hueFor(name)));
  }
  function tiles(list) {
    list?.querySelectorAll('.site-pill').forEach(row => {
      if (row.querySelector('.ui-tile')) return;
      const name = (row.querySelector('span')?.textContent || '').trim();
      const t = document.createElement('span'); t.className = 'ui-tile'; t.setAttribute('aria-hidden', 'true');
      t.textContent = (name.replace(/^https?:\/\//, '')[0] || '•').toUpperCase();
      row.prepend(t);
    });
  }
  function run() {
    const u = document.getElementById('username');
    if (u) avatar(document.querySelector('.status-card .status-line'), u);
    const n = document.getElementById('adminNameValue');
    if (n) avatar(document.querySelector('.name-card'), n);
    tiles(document.getElementById('sitesList'));
  }
  const start = () => {
    run();
    const targets = ['username', 'adminNameValue', 'sitesList'].map(id => document.getElementById(id)).filter(Boolean);
    const mo = new MutationObserver(run);
    targets.forEach(t => mo.observe(t, { childList: true, characterData: true, subtree: true }));
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
