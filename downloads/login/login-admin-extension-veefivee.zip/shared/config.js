globalThis.CS = globalThis.CS || {};
CS.CONFIG = Object.freeze({
  // v6.1.64: all database traffic goes to our own address, which forwards to
  // the current database. Moving the database only changes the forwarder.
  // If the forwarder can't be reached, requests fall back to the direct address.
  supabaseUrl: "https://api-login.veefivee.com",
  supabaseFallbackUrl: "https://thdxsonrjazeoadhidbx.supabase.co",
  supabasePublishableKey: "sb_publishable_Wk6lijFpADVLgxQkUnM2LA_nmkCqEXA",
  supabaseEdgeUrl: "https://api-login.veefivee.com/functions/v1/admin-users",
  // Use a small, sequential fallback chain so one public-IP provider outage
  // does not make a healthy proxy look broken. Only the first successful
  // endpoint is used, so normal health checks still make a single request.
  ipCheckUrls: Object.freeze([
    "https://api.ipify.org?format=json",
    "https://checkip.amazonaws.com/",
    "https://ipv4.icanhazip.com/"
  ]),
  version: "6.1.65"
});
